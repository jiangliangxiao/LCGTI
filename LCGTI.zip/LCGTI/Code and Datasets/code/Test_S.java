package ceka.test.My1.Test;

import ceka.consensus.ds.DawidSkene;
import ceka.consensus.glad.GLADWraper;
import ceka.consensus.gtic.GTIC;
import ceka.consensus.square.SquareIntegration;
import ceka.converters.FileLoader;
import ceka.core.Dataset;

import ceka.core.Example;
import ceka.core.MultiNoisyLabelSet;
import ceka.simulation.GaussianLabelingStrategy;
import ceka.simulation.MockWorker;
import ceka.simulation.SingleQualLabelingStrategy;
import ceka.test.My1.Alg.*;
import ceka.test.My1.Alg.DEWSMV.CWVNC;
import ceka.test.My1.Alg.DEWSMV.OptimizedError;
import ceka.test.My1.CekaUtils;
import ceka.test.My1.simulate.myGaussianLabelingStrategy;
import ceka.test.My1.simulate.myMockWorker;
import ceka.test.My1.simulate.mySingleQualLabelingStrategy;
import ceka.test.My3.Alg.RLRI.RobustLogisticInference1;
import ceka.utils.PerformanceStatistic;
import weka.classifiers.Classifier;
import weka.classifiers.trees.J48;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.ReplaceMissingValues;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class Test_S{
    static int m_nFold=10;
    private static Dataset m_dataset=null;




    private static String[] dataname={
            "anneal","audiology","autos","balance-scale","biodeg", "breast-cancer",
            "breast-w", "car", "credit-a","credit-g", "heart-c", "heart-h","heart-statlog", "hepatitis",
            "horse-colic", "hypothyroid", "ionosphere", "diabetes","iris","kr-vs-kp", "labor", "lymph",
            "mushroom","segment", "sick",
            "sonar","spambase","tic-tac-toe", "vehicle",
            "vote",
            "vowel","waveform","zoo",//"letter"
           };

    //多类
//    private static String[] dataname={
//            "anneal","audiology","autos","balance-scale","car","heart-c","heart-h","hypothyroid","iris","lymph","segment",
//            "vehicle","vowel","waveform","zoo"
//    };

    //二类
//        private static String[] dataname={
//            "biodeg","breast-cancer","breast-w","credit-a","credit-g",
//            "diabetes","heart-statlog","hepatitis","horse-colic","ionosphere","kr-vs-kp","labor","mushroom",
//            "sick","sonar","spambase","tic-tac-toe","vote",
//         };




    public void readData(int m_choose) throws Exception {

        //For syn_data:
//        String arffPath="Ceka-v1.0.1/src/ceka/myProject/data/synthetic/"+dataname[m_choose]+".arff";
        String arffPath="Ceka-v1.0.1/data/myData1/simulation/"+dataname[m_choose]+".arff";
        m_dataset = FileLoader.loadFile(arffPath);

        //补全缺失值
        ReplaceMissingValues m_Missing = new ReplaceMissingValues();
        m_Missing.setInputFormat(m_dataset);
        Instances instances = Filter.useFilter(m_dataset, m_Missing);
        m_dataset = CekaUtils.instancesToDataset(instances,m_dataset);
    }


    public  static void mySimulateDataset(Dataset dataset,int numWorkers){
        myMockWorker[] mockWorkers = new myMockWorker[numWorkers];
        double[] p=new double[numWorkers];

        HashMap<Integer, List<String>> workerList=new HashMap<>();
        for(int r = 0; r < numWorkers; r++) {
            workerList.put(r, new ArrayList<String>());
            p[r]=Math.random();
        }
        for(int i=0;i<dataset.getExampleSize();i++){
            Example example=dataset.getExampleByIndex(i);
            int count=0;
            for(int r = 0; r < numWorkers; r++) {

                if (Math.random() < p[r]) {
                    count++;
                    workerList.get(r).add(example.getId());
                }
            }
            if(count==0)
            {
//                System.out.println("exist");
                i--;
            }
        }

//均匀分布
        double max=0.75 ;
        double min=0.55;
        for (int j = 0; j < numWorkers; j++) {
            System.out.println(j+": "+workerList.get(j).size()+" ");
            double quality=Math.random()*(max-min)+min;
//            System.out.println(quality);
            mySingleQualLabelingStrategy strategy = new mySingleQualLabelingStrategy(quality);

            mockWorkers[j] = new myMockWorker(String.valueOf(j));
            mockWorkers[j].setSingleQuality(quality);
            mockWorkers[j].labeling(dataset, strategy,workerList.get(j));
        }

//        //高斯分布
//        myGaussianLabelingStrategy strategy = new myGaussianLabelingStrategy(0.65,0.1);
//        for (int j = 0; j < numWorkers; j++) {
//            mockWorkers[j]=new myMockWorker(String.valueOf(j));
//        }
//        strategy.assignWorkerQuality(mockWorkers);
//        for (int j = 0; j < numWorkers; j++) {
//            mockWorkers[j].labeling(dataset, strategy, workerList.get(j));
//        }
//        System.out.println();
    }

    public  static void simulateDataset(Dataset dataset,int numWorkers){
        MockWorker[] mockWorkers = new MockWorker[numWorkers];
        double max=0.9 ;
        double min=0.4 ;

        for (int j = 0; j < numWorkers; j++) {
            double quality=Math.random()*(max-min)+min;
            System.out.print(quality+" ");
            SingleQualLabelingStrategy strategy = new SingleQualLabelingStrategy(quality);

            mockWorkers[j] = new MockWorker(String.valueOf(j));
            mockWorkers[j].setSingleQuality(quality);
            mockWorkers[j].labeling(dataset, strategy);
        }
        System.out.println();

    }



    public static void main(String[] args) throws Exception {
        String resultPath1 = "Ceka-v1.0.1/src/ceka/test/My1/result/labelQualty_S.txt";
        FileOutputStream fs1 = new FileOutputStream(new File(resultPath1));
        PrintStream result1 = new PrintStream(fs1);
        result1.format("%-20s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s", "Dataset",   "MV","DS","GTIC","DEWSWMV","MNLDP","LAWMV","CWVNC","LCGTI");
        result1.println();

        String resultPath2 = "Ceka-v1.0.1/src/ceka/test/My1/result/modelQuality_S.txt";
        FileOutputStream fs2 = new FileOutputStream(new File(resultPath2));
        PrintStream result2 = new PrintStream(fs2);
        result2.format("%-20s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s", "Dataset",   "MV","DS","GTIC","DEWSWMV","MNLDP","LAWMV","CWVNC","LCGTI");
        result2.println();


        Classifier classifier=new J48();

        double meanMV=0;
        double meanLCGTI=0;
        double meanLCGTI_LS=0;
        double meanCMVNC=0;
        double meanGTIC=0;
        double meanDeError=0;
        double meanMNLDP=0;
        double meanDS=0;
        double meanKOS=0;
        double meanLAWMV=0;

        double meanModelMV=0;
        double meanModelLCGTI=0;
        double meanModelLCGTI_LS=0;
        double meanModelCMVNC=0;
        double meanModelGTIC=0;
        double meanModelDeError=0;
        double meanModelMNLDP=0;
        double meanModelDS=0;
        double meanModelKOS=0;
        double meanModelLAWMV=0;

        for(int i=0;i<dataname.length;i++){

            double accMV=0;
            double accDS=0;
            double accKOS=0;
            double accLAWMV=0;
            double accGTIC=0;
            double accDeError=0;
            double accMNLDP=0;
            double accLCGTI=0;
            double accLCGTI_LS=0;
            double accCMVNC=0;

            double accModelMV=0;
            double accModelDS=0;
            double accModelKOS=0;
            double accModelLAWMV=0;
            double accModelGTIC=0;
            double accModelDeError=0;
            double accModelMNLDP=0;
            double accModelLCGTI=0;
            double accModelLCGTI_LS=0;
            double accModelCMVNC=0;



            Test_S expriment=new Test_S();
            expriment.readData(i);

            for (int nFold = 0; nFold < m_nFold; nFold++) {

                simulateDataset(m_dataset,9);
//                mySimulateDataset(m_dataset, 10);


               //MV
                Dataset datasetMV=CekaUtils.datasetCopy(m_dataset);
                MajorityVote mv=new MajorityVote();
                mv.doInference(datasetMV);
                accMV +=CekaUtils.integrationAccuracy(datasetMV);
                System.out.println("MV finish");





                Dataset datasetDS=CekaUtils.datasetCopy(m_dataset);
                DawidSkene DS = new DawidSkene(50);
                DS.doInference(datasetDS);
                accDS +=CekaUtils.integrationAccuracy(datasetDS);
//                accModelZC +=CekaUtils.classificationAccuracy(datasetDS,1,10,classifier);
                System.out.println("DS :"+ CekaUtils.integrationAccuracy(datasetDS));
                System.out.println("DS finish");
//


               //GTIC
                Dataset datasetGTIC=CekaUtils.datasetCopy(m_dataset);
                GTIC gtic = new GTIC("Ceka-v1.0.1/src/ceka/test/My1/result/GTIC/");
                gtic.doInference(datasetGTIC);
                accGTIC +=CekaUtils.integrationAccuracy(datasetGTIC);
//                accModelGTIC+=CekaUtils.classificationAccuracy(datasetGTIC,1,10,classifier);
                System.out.println("GTIC:"+ CekaUtils.integrationAccuracy(datasetGTIC));
                System.out.println("GTIC finish");


                //DEWSWMV
                Dataset datasetDeError=CekaUtils.datasetCopy(m_dataset);
                OptimizedError de_error =new OptimizedError();
                de_error.DE_search(datasetDeError);
                accDeError +=CekaUtils.integrationAccuracy(datasetDeError);
//                accModelDeError +=CekaUtils.classificationAccuracy(datasetDeError,1,10,classifier);
                System.out.println("DEWSMV :"+ CekaUtils.integrationAccuracy(datasetDeError));
                System.out.println("DEWSMV finish");

                Dataset datasetMNLDP=CekaUtils.datasetCopy(m_dataset);
                MNLDP mnldp=new MNLDP();
                mnldp.doInference(datasetMNLDP);
                accMNLDP+=CekaUtils.integrationAccuracy(datasetMNLDP);
//                accModelMNLDP+=CekaUtils.classificationAccuracy(datasetMNLDP,1,10,classifier);
                System.out.println("MNLDP :"+ CekaUtils.integrationAccuracy(datasetMNLDP));
                System.out.println("MNLDP finish");

               //LAWMV
                Dataset datasetLAWMV=CekaUtils.datasetCopy(m_dataset);
                LAWMV lawmv = new LAWMV();
                lawmv.doInference(datasetLAWMV, (int)(0.5*datasetLAWMV.numInstances() / datasetLAWMV.numClasses()));
                accLAWMV +=CekaUtils.integrationAccuracy(datasetLAWMV);
//                accModelLAWMV+=CekaUtils.classificationAccuracy(datasetLAWMV,1,10,classifier);
                System.out.println("LAWMV :"+ CekaUtils.integrationAccuracy(datasetLAWMV));
                System.out.println("LAWMV finish");


                //CMVNC
//                Dataset datasetCMVNC=CekaUtils.datasetCopy(m_dataset);
//                mv.doInference(datasetCMVNC);
//                CMVNC cmvnc = new CMVNC();
//                cmvnc.doInference(datasetCMVNC);
//                accCMVNC +=CekaUtils.integrationAccuracy(datasetCMVNC);
////                accModelCMVNC+=CekaUtils.classificationAccuracy(datasetLAWMV,1,10,classifier);
//                System.out.println("CMVNC :"+ CekaUtils.integrationAccuracy(datasetLAWMV));
//                System.out.println("CMVNC finsihed");

                Dataset datasetLCGTI=CekaUtils.datasetCopy(m_dataset);
                double a=datasetLCGTI.getExampleSize()/datasetLCGTI.getCategorySize();
                int k=(int)(a*0.5);
                LCGTI my2=new LCGTI();
                my2.doInference(datasetLCGTI,(int)(k),0);
                accLCGTI += CekaUtils.integrationAccuracy(datasetLCGTI);
//                accModelLCGTI += CekaUtils.classificationAccuracy(datasetLCGTI,1,10,classifier);
                System.out.println("LCGTI :"+ CekaUtils.integrationAccuracy(datasetLCGTI));
                System.out.println("LCGTI finish");

                System.out.println("################################################");
                System.out.println(dataname[i]+" "+nFold+" fold finish");
                System.out.println("################################################");
            }

            accMV=accMV/(double)m_nFold;
            accDS=accDS/(double)m_nFold;
            accKOS=accKOS/(double)m_nFold;
            accLAWMV=accLAWMV/(double) m_nFold;
            accGTIC=accGTIC/(double)m_nFold;
            accDeError=accDeError/(double)m_nFold;
            accMNLDP=accMNLDP/(double)m_nFold;
            accLCGTI=accLCGTI/(double)m_nFold;
            accLCGTI_LS=accLCGTI_LS/(double)m_nFold;
            accCMVNC=accCMVNC/(double)m_nFold;


            accModelMV=accModelMV/(double)m_nFold;
            accModelDS=accModelDS/(double)m_nFold;
            accModelKOS=accModelKOS/(double)m_nFold;
            accModelLAWMV=accModelLAWMV/(double) m_nFold;
            accModelDeError=accModelDeError/(double) m_nFold;
            accModelGTIC=accModelGTIC/(double) m_nFold;
            accModelMNLDP=accModelMNLDP/(double) m_nFold;
            accModelLCGTI=accModelLCGTI/(double)m_nFold;
            accModelLCGTI_LS=accModelLCGTI_LS/(double)m_nFold;
            accModelCMVNC=accModelCMVNC/(double)m_nFold;


            meanMV += accMV;
            meanDS +=accDS;
            meanKOS +=accKOS;
            meanLAWMV +=accLAWMV;
            meanGTIC +=accGTIC;
            meanDeError +=accDeError;
            meanMNLDP +=accMNLDP;
            meanLCGTI += accLCGTI;
            meanLCGTI_LS +=accLCGTI_LS;
            meanCMVNC +=accCMVNC;

            meanModelMV += accModelMV;
            meanModelDS +=accModelDS;
            meanModelKOS +=accModelKOS;
            meanModelLAWMV +=accModelLAWMV;
            meanModelGTIC +=accModelGTIC;
            meanModelDeError +=accModelDeError;
            meanModelMNLDP +=accModelMNLDP;
            meanModelLCGTI += accModelLCGTI;
            meanModelLCGTI_LS +=accModelLCGTI_LS;
            meanModelCMVNC += accModelCMVNC;
            result1.format("%-20s %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f", dataname[i],
                    accMV, accDS,accGTIC,accDeError,accMNLDP,accLAWMV,accCMVNC, accLCGTI);
            result1.println();

            result2.format("%-20s %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f", dataname[i],
                    accModelMV, accModelDS,accModelGTIC,accDeError,accModelMNLDP,accModelLAWMV,accModelCMVNC,accModelLCGTI);
            result2.println();

            System.out.println();
        }
        meanMV/=dataname.length;
        meanDS/=dataname.length;
        meanLAWMV /=dataname.length;
        meanKOS /=dataname.length;
        meanGTIC /=dataname.length;
        meanDeError /=dataname.length;
        meanMNLDP /=dataname.length;
        meanLCGTI/=dataname.length;
        meanLCGTI_LS/=dataname.length;
        meanCMVNC/=dataname.length;

        meanModelMV/=dataname.length;
        meanModelDS/=dataname.length;
        meanModelKOS/=dataname.length;
        meanModelLAWMV /=dataname.length;
        meanModelGTIC /=dataname.length;
        meanModelDeError /=dataname.length;
        meanModelMNLDP /=dataname.length;
        meanModelLCGTI/=dataname.length;
        meanModelLCGTI_LS/=dataname.length;
        meanModelCMVNC/=dataname.length;

        result1.format("%-20s %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f","Mean",
                meanMV,meanDS,meanGTIC,meanDeError,meanMNLDP,meanLAWMV, meanCMVNC,meanLCGTI);
        result1.println();
        result1.close();

        result2.format("%-20s %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f","Mean",
                meanModelMV,meanModelDS,meanModelGTIC,meanModelDeError,meanModelMNLDP,meanModelLAWMV, meanModelCMVNC,meanModelLCGTI);
        result2.println();
        result2.close();
        System.out.println();


    }
}
